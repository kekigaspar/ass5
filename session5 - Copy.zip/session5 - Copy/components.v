// Available components:

// Inverter
module inv (
	input  a,
    	output y
);
    	assign  y = ~a;
endmodule

// Two input AND
module and_2 (
    	input  a,
    	input  b,
    	output y
);
    	assign  y = a & b;
endmodule

// Four input AND
module and_4 (
    	input  a,
    	input  b,
    	input  c,
    	input  d,
    	output y
);
    	assign  y = a & b & c & d;
endmodule

// Five input AND
module and_5 (
    	input  a,
    	input  b,
    	input  c,
    	input  d,
    	input  e,
    	output y
);
    	assign  y = a & b & c & d & e;
endmodule

// Two input NAND
module nand_2 (
    	input  a,
    	input  b,
    	output y
);
    	assign  y = ~(a & b);
endmodule

// Two input OR
module or_2 (
    	input  a,
    	input  b,
    	output y
);
    	assign  y = a | b;
endmodule

// Three input OR
module or_3 (
    	input  a,
    	input  b,
    	input  c,
    	output y
);
    	assign  y = a | b | c;
endmodule

// Four input OR
module or_4 (
    	input  a,
    	input  b,
    	input  c,
    	input  d,
    	output y
);
    	assign y = a | b | c | d;
endmodule

// Five input OR
module or_5 (
    	input  a,
    	input  b,
    	input  c,
    	input  d,
    	input  e,
    	output y
);
    	assign  y = a | b | c | d | e;
endmodule

// Two input NOR
module nor_2 (
    	input  a,
    	input  b,
    	output y
);
    	assign  y = ~(a | b);
endmodule

// XOR
module xor_2 (
    	input  a,
    	input  b,
    	output reg y
);
    	always @(*) begin
        	if (a == b) begin
            		 y = 0;
        	end else begin
            		 y = 1;
        	end
    	end
endmodule

// 2:1 Multiplexer
module mux21 (
    	input  a,
    	input  b,
    	input  sel,
    	output y
);
    	assign  y = (a & ~sel) | (b & sel);
endmodule

// Full adder
module fadder (
    	input  a,
    	input  b,
    	input  ci,
    	output sum,
    	output co
);
    	wire s1, s2, s3, s4;

    	and_2 U1 (.a(a), .b(b), .y(s1));
    	and_2 U2 (.a(a), .b(ci), .y(s2));
    	and_2 U3 (.a(b), .b(ci), .y(s3));
    	or_3  U4 (.a(s1), .b(s2), .c(s3), .y(co));
    	xor_2 U5 (.a(a), .b(b), .y(s4));
    	xor_2 U6 (.a(s4), .b(ci), .y(sum));
endmodule











