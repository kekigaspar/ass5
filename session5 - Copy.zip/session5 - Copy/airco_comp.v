// Extended full adder
module ex_fadder(
    input  a, b, sel, ci,
    output sum, co
);
    wire nb;
    wire s1;
    
    // Inverter for b
    inv lbl0 (.a(b), .y(nb));
    // assign #5 nb = ~b;
    
    // 2:1 MUX for selecting between b and ~b
    mux21 lbl1 (.a(b), .b(nb), .sel(sel), .y(s1));
    //assign #10 s1 = (sel) ? nb : b;
    
    // Full adder operation
    fadder lbl2 (.a(a), .b(s1), .ci(ci), .sum(sum), .co(co));
    
endmodule

// Eight bit adder
// 2's complement 8-bit adder/substractor
// A, B input operands
// f = 0 compute C = A+B
// f = 1 compute C = A-B
// o overflow flag
// z zero flag
// the sign flag is C(7)! 

module eight_bitadder(
    input [7:0] A,
    input [7:0] B,
    input f,
    inout [7:0] C,
    output o, z
);

   

    // Instantiate extended full adder modules
	wire [7:0] ca;
	
	ex_fadder add0 (.a(A[0]), .b(B[0]), .sel(f), .ci(f), .sum(C[0]), .co(ca[0]));
	ex_fadder add1 (.a(A[1]), .b(B[1]), .sel(f), .ci(ca[0]), .sum(C[1]), .co(ca[1]));
	ex_fadder add2 (.a(A[2]), .b(B[2]), .sel(f), .ci(ca[1]), .sum(C[2]), .co(ca[2]));
	ex_fadder add3 (.a(A[3]), .b(B[3]), .sel(f), .ci(ca[2]), .sum(C[3]), .co(ca[3]));
	ex_fadder add4 (.a(A[4]), .b(B[4]), .sel(f), .ci(ca[3]), .sum(C[4]), .co(ca[4]));
	ex_fadder add5 (.a(A[5]), .b(B[5]), .sel(f), .ci(ca[4]), .sum(C[5]), .co(ca[5]));
	ex_fadder add6 (.a(A[6]), .b(B[6]), .sel(f), .ci(ca[5]), .sum(C[6]), .co(ca[6]));
	ex_fadder add7 (.a(A[7]), .b(B[7]), .sel(f), .ci(ca[6]), .sum(C[7]), .co(ca[7]));
   	
	xor_2 xor21 (.a(ca[6]), .b(ca[7]), .y(o));

	wire [2:0] oo;
	
	or_4 or41 (.a(C[0]), .b(C[1]), .c(C[2]), .d(C[3]), .y(oo[0]));
	or_4 or42 (.a(C[4]), .b(C[5]), .c(C[6]), .d(C[7]), .y(oo[1]));
	or_2 or2 (.a(oo[0]), .b(oo[1]), .y(oo[2]));

	inv inv1 (.a(oo[2]), .y(z));

endmodule

// Add comp
// A, B, C input operands (8-bit 2's complement!)
// compute D = A - (B + C)
// gz = 1 if D > 0
// o overflow flag

module add_comp(
    input [7:0] A,
    input [7:0] B,
    input [7:0] C,
    output gz, o
);
	wire[7:0] BaC;
	wire BaCo;

	eight_bitadder bc (.A(B), .B(C), .f(1'b0), .C(BaC), .o(BaCo), .z());
	
	wire[7:0] AmBaC;
	wire AmBaCo;
	wire Dz;

	eight_bitadder abc (.A(A), .B(BaC), .f(1'b1), .C(AmBaC), .o(AmBaCo), .z(Dz));
	
	nor_2 nor21 (.a(AmBaC[7]), .b(Dz), .y(gz));
	
	or_2 or21 (.a(BaCo), .b(AmBaCo), .y(o));

endmodule

// Airco_comp
// Tin-(Tref+Td)
// Tref-(Tin+td)

module airco_comp(
    input [7:0] Tin,
    input [7:0] Tref,
    input [7:0] Td,
    output c0, c1
);
	
	wire [1:0] tc;
	
	add_comp tooBig (.A(Tin), .B(Tref), .C(Td), .gz(tc[0]), .o());
	add_comp tooSmall (.A(Tref), .B(Tin), .C(Td), .gz(tc[1]), .o());

	or_2 or21 (.a(tc[0]), .b(tc[1]), .y(c0));

	add_comp c1calc (.A(Tin), .B(Tref), .C(8'b00000000), .gz(c1), .o());

endmodule

