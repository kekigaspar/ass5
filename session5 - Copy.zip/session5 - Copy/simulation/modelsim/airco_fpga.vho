-- Copyright (C) 1991-2013 Altera Corporation
-- Your use of Altera Corporation's design tools, logic functions 
-- and other software and tools, and its AMPP partner logic 
-- functions, and any output files from any of the foregoing 
-- (including device programming or simulation files), and any 
-- associated documentation or information are expressly subject 
-- to the terms and conditions of the Altera Program License 
-- Subscription Agreement, Altera MegaCore Function License 
-- Agreement, or other applicable license agreement, including, 
-- without limitation, that your use is for the sole purpose of 
-- programming logic devices manufactured by Altera and sold by 
-- Altera or its authorized distributors.  Please refer to the 
-- applicable agreement for further details.

-- VENDOR "Altera"
-- PROGRAM "Quartus II 64-Bit"
-- VERSION "Version 13.1.0 Build 162 10/23/2013 SJ Web Edition"

-- DATE "10/09/2026 10:45:19"

-- 
-- Device: Altera EP3C16F484C6 Package FBGA484
-- 

-- 
-- This VHDL file should be used for ModelSim-Altera (VHDL) only
-- 

LIBRARY ALTERA;
LIBRARY CYCLONEIII;
LIBRARY IEEE;
USE ALTERA.ALTERA_PRIMITIVES_COMPONENTS.ALL;
USE CYCLONEIII.CYCLONEIII_COMPONENTS.ALL;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY 	airco IS
    PORT (
	clk : IN std_logic;
	reset : IN std_logic;
	Z : IN std_logic;
	E : IN std_logic;
	W : IN std_logic;
	G : IN std_logic;
	Tin : IN std_logic_vector(7 DOWNTO 0);
	heat : OUT std_logic;
	cool : OUT std_logic;
	off : OUT std_logic;
	service : OUT std_logic
	);
END airco;

-- Design Ports Information
-- heat	=>  Location: PIN_T14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- cool	=>  Location: PIN_R14,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- off	=>  Location: PIN_U12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- service	=>  Location: PIN_T12,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Z	=>  Location: PIN_G4,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- E	=>  Location: PIN_H6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- W	=>  Location: PIN_H5,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- G	=>  Location: PIN_J6,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[5]	=>  Location: PIN_U15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[2]	=>  Location: PIN_V15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[0]	=>  Location: PIN_AB7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[1]	=>  Location: PIN_AA7,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[3]	=>  Location: PIN_W15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[7]	=>  Location: PIN_Y17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[4]	=>  Location: PIN_T15,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- Tin[6]	=>  Location: PIN_W17,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- clk	=>  Location: PIN_G21,	 I/O Standard: 2.5 V,	 Current Strength: Default
-- reset	=>  Location: PIN_F1,	 I/O Standard: 2.5 V,	 Current Strength: Default


ARCHITECTURE structure OF airco IS
SIGNAL gnd : std_logic := '0';
SIGNAL vcc : std_logic := '1';
SIGNAL unknown : std_logic := 'X';
SIGNAL devoe : std_logic := '1';
SIGNAL devclrn : std_logic := '1';
SIGNAL devpor : std_logic := '1';
SIGNAL ww_devoe : std_logic;
SIGNAL ww_devclrn : std_logic;
SIGNAL ww_devpor : std_logic;
SIGNAL ww_clk : std_logic;
SIGNAL ww_reset : std_logic;
SIGNAL ww_Z : std_logic;
SIGNAL ww_E : std_logic;
SIGNAL ww_W : std_logic;
SIGNAL ww_G : std_logic;
SIGNAL ww_Tin : std_logic_vector(7 DOWNTO 0);
SIGNAL ww_heat : std_logic;
SIGNAL ww_cool : std_logic;
SIGNAL ww_off : std_logic;
SIGNAL ww_service : std_logic;
SIGNAL \clk~inputclkctrl_INCLK_bus\ : std_logic_vector(3 DOWNTO 0);
SIGNAL \heat~output_o\ : std_logic;
SIGNAL \cool~output_o\ : std_logic;
SIGNAL \off~output_o\ : std_logic;
SIGNAL \service~output_o\ : std_logic;
SIGNAL \clk~input_o\ : std_logic;
SIGNAL \clk~inputclkctrl_outclk\ : std_logic;
SIGNAL \Tin[5]~input_o\ : std_logic;
SIGNAL \Tin[0]~input_o\ : std_logic;
SIGNAL \Tin[1]~input_o\ : std_logic;
SIGNAL \Tin[3]~input_o\ : std_logic;
SIGNAL \Tin[2]~input_o\ : std_logic;
SIGNAL \lbl0|or21|y~0_combout\ : std_logic;
SIGNAL \Tin[6]~input_o\ : std_logic;
SIGNAL \Tin[4]~input_o\ : std_logic;
SIGNAL \Tin[7]~input_o\ : std_logic;
SIGNAL \lbl0|or21|y~1_combout\ : std_logic;
SIGNAL \lbl0|or21|y~2_combout\ : std_logic;
SIGNAL \E~input_o\ : std_logic;
SIGNAL \G~input_o\ : std_logic;
SIGNAL \Z~input_o\ : std_logic;
SIGNAL \W~input_o\ : std_logic;
SIGNAL \lbl1|always1~0_combout\ : std_logic;
SIGNAL \lbl0|c1calc|abc|add7|lbl2|U6|y~combout\ : std_logic;
SIGNAL \lbl0|c1calc|abc|or41|y~0_combout\ : std_logic;
SIGNAL \lbl1|Selector1~5_combout\ : std_logic;
SIGNAL \lbl1|new_state.off_state~0_combout\ : std_logic;
SIGNAL \reset~input_o\ : std_logic;
SIGNAL \lbl1|state.off_state~q\ : std_logic;
SIGNAL \lbl1|state.service_state~q\ : std_logic;
SIGNAL \lbl1|Selector1~2_combout\ : std_logic;
SIGNAL \lbl1|Selector1~3_combout\ : std_logic;
SIGNAL \lbl1|state.heat_state~q\ : std_logic;
SIGNAL \lbl0|c1calc|abc|or41|y~1_combout\ : std_logic;
SIGNAL \lbl1|Selector1~4_combout\ : std_logic;
SIGNAL \lbl1|Selector0~0_combout\ : std_logic;
SIGNAL \lbl1|Selector0~1_combout\ : std_logic;
SIGNAL \lbl1|state.cool_state~q\ : std_logic;
SIGNAL \lbl1|ALT_INV_state.off_state~q\ : std_logic;

BEGIN

ww_clk <= clk;
ww_reset <= reset;
ww_Z <= Z;
ww_E <= E;
ww_W <= W;
ww_G <= G;
ww_Tin <= Tin;
heat <= ww_heat;
cool <= ww_cool;
off <= ww_off;
service <= ww_service;
ww_devoe <= devoe;
ww_devclrn <= devclrn;
ww_devpor <= devpor;

\clk~inputclkctrl_INCLK_bus\ <= (vcc & vcc & vcc & \clk~input_o\);
\lbl1|ALT_INV_state.off_state~q\ <= NOT \lbl1|state.off_state~q\;

-- Location: IOOBUF_X32_Y0_N16
\heat~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \lbl1|state.heat_state~q\,
	devoe => ww_devoe,
	o => \heat~output_o\);

-- Location: IOOBUF_X39_Y0_N16
\cool~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \lbl1|state.cool_state~q\,
	devoe => ww_devoe,
	o => \cool~output_o\);

-- Location: IOOBUF_X26_Y0_N2
\off~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \lbl1|ALT_INV_state.off_state~q\,
	devoe => ww_devoe,
	o => \off~output_o\);

-- Location: IOOBUF_X28_Y0_N30
\service~output\ : cycloneiii_io_obuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	open_drain_output => "false")
-- pragma translate_on
PORT MAP (
	i => \lbl1|state.service_state~q\,
	devoe => ww_devoe,
	o => \service~output_o\);

-- Location: IOIBUF_X41_Y15_N1
\clk~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_clk,
	o => \clk~input_o\);

-- Location: CLKCTRL_G9
\clk~inputclkctrl\ : cycloneiii_clkctrl
-- pragma translate_off
GENERIC MAP (
	clock_type => "global clock",
	ena_register_mode => "none")
-- pragma translate_on
PORT MAP (
	inclk => \clk~inputclkctrl_INCLK_bus\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	outclk => \clk~inputclkctrl_outclk\);

-- Location: IOIBUF_X39_Y0_N29
\Tin[5]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(5),
	o => \Tin[5]~input_o\);

-- Location: IOIBUF_X11_Y0_N8
\Tin[0]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(0),
	o => \Tin[0]~input_o\);

-- Location: IOIBUF_X11_Y0_N15
\Tin[1]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(1),
	o => \Tin[1]~input_o\);

-- Location: IOIBUF_X32_Y0_N22
\Tin[3]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(3),
	o => \Tin[3]~input_o\);

-- Location: IOIBUF_X32_Y0_N29
\Tin[2]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(2),
	o => \Tin[2]~input_o\);

-- Location: LCCOMB_X32_Y1_N8
\lbl0|or21|y~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl0|or21|y~0_combout\ = (!\Tin[3]~input_o\ & (\Tin[2]~input_o\ & ((\Tin[0]~input_o\) # (\Tin[1]~input_o\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000111000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[0]~input_o\,
	datab => \Tin[1]~input_o\,
	datac => \Tin[3]~input_o\,
	datad => \Tin[2]~input_o\,
	combout => \lbl0|or21|y~0_combout\);

-- Location: IOIBUF_X35_Y0_N8
\Tin[6]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(6),
	o => \Tin[6]~input_o\);

-- Location: IOIBUF_X32_Y0_N8
\Tin[4]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(4),
	o => \Tin[4]~input_o\);

-- Location: IOIBUF_X35_Y0_N1
\Tin[7]~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Tin(7),
	o => \Tin[7]~input_o\);

-- Location: LCCOMB_X32_Y1_N18
\lbl0|or21|y~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl0|or21|y~1_combout\ = (\Tin[7]~input_o\) # ((\Tin[3]~input_o\ & ((\Tin[4]~input_o\) # (!\Tin[2]~input_o\))) # (!\Tin[3]~input_o\ & (!\Tin[4]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111100111111011",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[3]~input_o\,
	datab => \Tin[4]~input_o\,
	datac => \Tin[7]~input_o\,
	datad => \Tin[2]~input_o\,
	combout => \lbl0|or21|y~1_combout\);

-- Location: LCCOMB_X32_Y1_N28
\lbl0|or21|y~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl0|or21|y~2_combout\ = (\Tin[5]~input_o\) # ((\lbl0|or21|y~0_combout\) # ((\lbl0|or21|y~1_combout\) # (!\Tin[6]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111111111101111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[5]~input_o\,
	datab => \lbl0|or21|y~0_combout\,
	datac => \Tin[6]~input_o\,
	datad => \lbl0|or21|y~1_combout\,
	combout => \lbl0|or21|y~2_combout\);

-- Location: IOIBUF_X0_Y25_N22
\E~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_E,
	o => \E~input_o\);

-- Location: IOIBUF_X0_Y24_N1
\G~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_G,
	o => \G~input_o\);

-- Location: IOIBUF_X0_Y23_N8
\Z~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_Z,
	o => \Z~input_o\);

-- Location: IOIBUF_X0_Y27_N1
\W~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_W,
	o => \W~input_o\);

-- Location: LCCOMB_X1_Y24_N0
\lbl1|always1~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|always1~0_combout\ = (((!\W~input_o\) # (!\Z~input_o\)) # (!\G~input_o\)) # (!\E~input_o\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0111111111111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \E~input_o\,
	datab => \G~input_o\,
	datac => \Z~input_o\,
	datad => \W~input_o\,
	combout => \lbl1|always1~0_combout\);

-- Location: LCCOMB_X32_Y1_N26
\lbl0|c1calc|abc|add7|lbl2|U6|y\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl0|c1calc|abc|add7|lbl2|U6|y~combout\ = \Tin[7]~input_o\ $ (((\Tin[6]~input_o\ & ((\Tin[4]~input_o\) # (\Tin[5]~input_o\)))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0110011001101010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[7]~input_o\,
	datab => \Tin[6]~input_o\,
	datac => \Tin[4]~input_o\,
	datad => \Tin[5]~input_o\,
	combout => \lbl0|c1calc|abc|add7|lbl2|U6|y~combout\);

-- Location: LCCOMB_X32_Y1_N24
\lbl0|c1calc|abc|or41|y~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl0|c1calc|abc|or41|y~0_combout\ = (!\Tin[0]~input_o\ & (!\Tin[1]~input_o\ & (\Tin[6]~input_o\ & !\Tin[5]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000000010000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[0]~input_o\,
	datab => \Tin[1]~input_o\,
	datac => \Tin[6]~input_o\,
	datad => \Tin[5]~input_o\,
	combout => \lbl0|c1calc|abc|or41|y~0_combout\);

-- Location: LCCOMB_X32_Y1_N4
\lbl1|Selector1~5\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|Selector1~5_combout\ = (!\Tin[3]~input_o\ & (\lbl0|c1calc|abc|or41|y~0_combout\ & (\Tin[4]~input_o\ & !\Tin[2]~input_o\)))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[3]~input_o\,
	datab => \lbl0|c1calc|abc|or41|y~0_combout\,
	datac => \Tin[4]~input_o\,
	datad => \Tin[2]~input_o\,
	combout => \lbl1|Selector1~5_combout\);

-- Location: LCCOMB_X32_Y1_N12
\lbl1|new_state.off_state~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|new_state.off_state~0_combout\ = (\lbl0|or21|y~2_combout\) # (\lbl1|always1~0_combout\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111101011111010",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \lbl0|or21|y~2_combout\,
	datac => \lbl1|always1~0_combout\,
	combout => \lbl1|new_state.off_state~0_combout\);

-- Location: IOIBUF_X0_Y23_N1
\reset~input\ : cycloneiii_io_ibuf
-- pragma translate_off
GENERIC MAP (
	bus_hold => "false",
	simulate_z_as => "z")
-- pragma translate_on
PORT MAP (
	i => ww_reset,
	o => \reset~input_o\);

-- Location: FF_X32_Y1_N13
\lbl1|state.off_state\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \lbl1|new_state.off_state~0_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \lbl1|state.off_state~q\);

-- Location: FF_X32_Y1_N23
\lbl1|state.service_state\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	asdata => \lbl1|always1~0_combout\,
	clrn => \reset~input_o\,
	sload => VCC,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \lbl1|state.service_state~q\);

-- Location: LCCOMB_X32_Y1_N6
\lbl1|Selector1~2\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|Selector1~2_combout\ = (\lbl0|c1calc|abc|add7|lbl2|U6|y~combout\ & (\lbl1|Selector1~5_combout\ & ((\lbl1|state.service_state~q\) # (!\lbl1|state.off_state~q\)))) # (!\lbl0|c1calc|abc|add7|lbl2|U6|y~combout\ & (((\lbl1|state.service_state~q\) # 
-- (!\lbl1|state.off_state~q\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1101110100001101",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \lbl0|c1calc|abc|add7|lbl2|U6|y~combout\,
	datab => \lbl1|Selector1~5_combout\,
	datac => \lbl1|state.off_state~q\,
	datad => \lbl1|state.service_state~q\,
	combout => \lbl1|Selector1~2_combout\);

-- Location: LCCOMB_X32_Y1_N20
\lbl1|Selector1~3\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|Selector1~3_combout\ = (\lbl0|or21|y~2_combout\ & (!\lbl1|always1~0_combout\ & ((\lbl1|state.heat_state~q\) # (\lbl1|Selector1~2_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \lbl0|or21|y~2_combout\,
	datab => \lbl1|always1~0_combout\,
	datac => \lbl1|state.heat_state~q\,
	datad => \lbl1|Selector1~2_combout\,
	combout => \lbl1|Selector1~3_combout\);

-- Location: FF_X32_Y1_N21
\lbl1|state.heat_state\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \lbl1|Selector1~3_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \lbl1|state.heat_state~q\);

-- Location: LCCOMB_X32_Y1_N22
\lbl0|c1calc|abc|or41|y~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl0|c1calc|abc|or41|y~1_combout\ = (!\Tin[3]~input_o\ & (\Tin[4]~input_o\ & !\Tin[2]~input_o\))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0000000001000100",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \Tin[3]~input_o\,
	datab => \Tin[4]~input_o\,
	datad => \Tin[2]~input_o\,
	combout => \lbl0|c1calc|abc|or41|y~1_combout\);

-- Location: LCCOMB_X32_Y1_N16
\lbl1|Selector1~4\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|Selector1~4_combout\ = (\lbl1|state.service_state~q\) # (!\lbl1|state.off_state~q\)

-- pragma translate_off
GENERIC MAP (
	lut_mask => "1111000011111111",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	datac => \lbl1|state.service_state~q\,
	datad => \lbl1|state.off_state~q\,
	combout => \lbl1|Selector1~4_combout\);

-- Location: LCCOMB_X32_Y1_N10
\lbl1|Selector0~0\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|Selector0~0_combout\ = (\lbl0|c1calc|abc|add7|lbl2|U6|y~combout\ & (\lbl1|Selector1~4_combout\ & ((!\lbl0|c1calc|abc|or41|y~1_combout\) # (!\lbl0|c1calc|abc|or41|y~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010101000000000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \lbl0|c1calc|abc|add7|lbl2|U6|y~combout\,
	datab => \lbl0|c1calc|abc|or41|y~0_combout\,
	datac => \lbl0|c1calc|abc|or41|y~1_combout\,
	datad => \lbl1|Selector1~4_combout\,
	combout => \lbl1|Selector0~0_combout\);

-- Location: LCCOMB_X32_Y1_N30
\lbl1|Selector0~1\ : cycloneiii_lcell_comb
-- Equation(s):
-- \lbl1|Selector0~1_combout\ = (\lbl0|or21|y~2_combout\ & (!\lbl1|always1~0_combout\ & ((\lbl1|state.cool_state~q\) # (\lbl1|Selector0~0_combout\))))

-- pragma translate_off
GENERIC MAP (
	lut_mask => "0010001000100000",
	sum_lutc_input => "datac")
-- pragma translate_on
PORT MAP (
	dataa => \lbl0|or21|y~2_combout\,
	datab => \lbl1|always1~0_combout\,
	datac => \lbl1|state.cool_state~q\,
	datad => \lbl1|Selector0~0_combout\,
	combout => \lbl1|Selector0~1_combout\);

-- Location: FF_X32_Y1_N31
\lbl1|state.cool_state\ : dffeas
-- pragma translate_off
GENERIC MAP (
	is_wysiwyg => "true",
	power_up => "low")
-- pragma translate_on
PORT MAP (
	clk => \clk~inputclkctrl_outclk\,
	d => \lbl1|Selector0~1_combout\,
	clrn => \reset~input_o\,
	devclrn => ww_devclrn,
	devpor => ww_devpor,
	q => \lbl1|state.cool_state~q\);

ww_heat <= \heat~output_o\;

ww_cool <= \cool~output_o\;

ww_off <= \off~output_o\;

ww_service <= \service~output_o\;
END structure;


