module airco_fsm_tb;

	reg clk = 0;
  	reg reset = 0;
  	reg Z = 1;
  	reg E = 1;
  	reg W = 1;
  	reg G = 1;
  	reg c0 = 0;
  	reg c1 = 0;
  	wire heat;
  	wire cool;
  	wire off;
  	wire service;

  	airco_fsm uut (
    		.clk(clk),
    		.reset(reset),
    		.Z(Z),
    		.E(E),
    		.W(W),
    		.G(G),
    		.c0(c0),
    		.c1(c1),
    		.heat(heat),
    		.cool(cool),
    		.off(off),
    		.service(service)
  	);

	always #10 clk = ~clk;

	initial begin
		#20 reset <= 1;
		#30 c0 <= 1;
		#150 c0 <= 0;
		#50 c0 <= 1; c1 <= 1;
		#200 c0 <= 0; c1 <= 0;
		#90 Z <= 0;
	end
endmodule
