module airco_tb;

    reg clk, reset;
    reg Z, E, W, G;
    reg [7:0] Tin, Tref, Td;

    wire c0, c1;
    wire heat, cool, off, service;

    // Instantiate airco_comp
    airco_comp lbl0 (Tin, Tref, Td, c0, c1);

    // Instantiate airco_fsm
    airco_fsm lbl1 (
        clk, reset, 
        Z, E, W, G,
        c0, c1,
        heat, cool, off, service
    );
    
	// Clock generation
    initial begin
        clk = 0;
        forever #10 clk = ~clk; // Toggle clock every 10 time units
    end

    // Initialize inputs
    initial begin
        // Initialize inputs
        reset = 0;
        Z = 1;
        E = 1;
        W = 1;
        G = 1;
        Tref = 8'b01010000; // 20 C
        Td = 8'b00000100; // 1 C
    end

	// Change Tin over time
	initial begin
		#0 Tin = 8'b01000000; // 16 C
        #300 Tin = 8'b01001100; // 19 C
        #300 Tin = 8'b01011100; // 23 C   
    end

	initial begin
        reset = 0;
        #40 reset = 1;
    end
endmodule
