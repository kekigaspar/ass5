module airco_comp_tb;
	reg [7:0] Tin, Td, Tref;
	wire c0, c1;
	
	airco_comp dut (
		.Tin(Tin),
		.Tref(Tref),
		.Td(Td),
		.c0(c0),
		.c1(c1)
	);

	initial begin
		Td = 8'b00000100;
		Tref = 8'b01010000; // 20 C
		Tin = 8'b01000000; // 16 C

		#300 Tin <= 8'b01001100; // 19 C
		#300 Tin <= 8'b01011100; //23 C
	end
endmodule
