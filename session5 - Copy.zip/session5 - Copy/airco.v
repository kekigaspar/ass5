module airco (
    input clk, reset,
    input Z, E, W, G,
    input [7:0] Tin,
    output heat, cool, off, service
);

    wire c0, c1;
    wire [7:0] Td, Tref;

    // Initialize constants
    assign Td = 8'b00000100; 
    assign Tref = 8'b01010000;

    // Instantiate airco_comp
    airco_comp lbl0 (Tin, Tref, Td, c0, c1);

    // Instantiate airco_fsm
    airco_fsm lbl1 (
        clk, reset, 
        Z, E, W, G,
        c0, c1,
        heat, cool, off, service
    );
endmodule
