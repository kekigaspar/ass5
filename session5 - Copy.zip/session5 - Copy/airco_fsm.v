module airco_fsm (
    input clk, reset,
    input Z, E, W, G,
    input c0, c1,
    output reg heat, cool, off, service
);

    reg [1:0] state;
    reg [1:0] new_state;

    parameter [1:0] off_state = 2'b00;
    parameter [1:0] cool_state = 2'b01;
    parameter [1:0] heat_state = 2'b10;
    parameter [1:0] service_state = 2'b11;

// ????    
	always @(posedge clk or negedge reset) begin
		if (!reset) begin
			state <= off_state;
		end else begin
        		state <= new_state;
		end
    	end

	always @(*) begin
        	case (state)
   			off_state: begin
				heat = 0;
				cool = 0;
				off = 1;
				service = 0;
                		if (Z && E && W && G) begin
                    			if (c0) begin
						if (c1) begin
							new_state <= cool_state;
						end else begin
							new_state <= heat_state;
						end
					end else begin
						new_state <= off_state;
					end
                		end else begin
                    			 new_state <= service_state;
                		end
            		end

            		cool_state: begin
        			heat = 0;
				cool = 1;
				off = 0;
				service = 0;
                		if (Z && E && W && G) begin
                    			if (c0) begin
						new_state <= cool_state;
					end else begin
						new_state <= off_state;
					end
                		end else begin
                    			 new_state <= service_state;
                		end
            		end

            		heat_state: begin
        			heat = 1;
				cool = 0;
				off = 0;
				service = 0;
                		if (Z && E && W && G) begin
                    			if (c0) begin
						new_state <= heat_state;
					end else begin
						new_state <= off_state;
					end
                		end else begin
                    			 new_state <= service_state;
                		end
            		end

			service_state: begin
        			heat = 0;
				cool = 0;
				off = 0;
				service = 1;
                		if (Z && E && W && G) begin
                    			if (c0) begin
						if (c1) begin
							new_state <= cool_state;
						end else begin
							new_state <= heat_state;
						end
					end else begin
						new_state <= off_state;
					end
                		end else begin
                    			 new_state <= service_state;
                		end
            		end
        	endcase
    	end
	
endmodule
